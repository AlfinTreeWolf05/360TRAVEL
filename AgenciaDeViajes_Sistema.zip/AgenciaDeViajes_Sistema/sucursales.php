<?php
require_once __DIR__ . '/config/BD.php'; 
require_once __DIR__ . '/config/Auth.php';

$fCiudad = trim((string)($_GET['ciudad'] ?? ''));
$ciudades = $sucursales = [];
$error = false;
try {
    // La sucursal virtual "En línea" no es un local físico: no se muestra.
    $ciudades = db()->query("SELECT DISTINCT ciudad FROM sucursales WHERE nombre_sucursal <> 'En línea' ORDER BY ciudad")->fetchAll(PDO::FETCH_COLUMN);
    $sql = "SELECT nombre_sucursal, direccion, ciudad, telefono, email FROM sucursales WHERE nombre_sucursal <> 'En línea'";
    $p = [];
    if ($fCiudad !== '') { $sql .= ' AND ciudad = ?'; $p[] = $fCiudad; }
    $st = db()->prepare($sql . ' ORDER BY ciudad, nombre_sucursal');
    $st->execute($p);
    $sucursales = $st->fetchAll();
} catch (PDOException $ex) {
    error_log('sucursales.php: ' . $ex->getMessage());
    $error = true;
}

$titulo = 'Travel 360 - Sucursales';
$css_extra = 'assets/css/pages.css';
include 'parts/head.php';
include 'parts/header.php';
?>
<main>
  <section class="page-head">
    <div class="wrap">
      <p class="etiqueta">Sucursales</p>
      <h1>Encuéntranos</h1>
      <p class="lead">Visítanos en cualquiera de nuestras sucursales, o reserva en línea.</p>
    </div>
  </section>
  <section class="wrap seccion-lista">
    <form class="buscador filtros filtros-1" method="get" action="sucursales.php">
      <label>Ciudad
        <select name="ciudad"><option value="">Todas</option>
          <?php foreach ($ciudades as $c): ?><option value="<?= e($c) ?>" <?= $fCiudad === $c ? 'selected' : '' ?>><?= e($c) ?></option><?php endforeach; ?>
        </select>
      </label>
      <button class="btn btn-teal" type="submit">Filtrar</button>
    </form>
    <?php if ($error): ?>
      <p class="vacio">No pudimos cargar las sucursales. Inténtalo más tarde.</p>
    <?php elseif (!$sucursales): ?>
      <p class="vacio">No hay sucursales en esa ciudad. <a href="sucursales.php">Ver todas</a></p>
    <?php else: ?>
      <div class="sucursales">
        <?php foreach ($sucursales as $s): ?>
          <article class="caja sucursal">
            <p class="etiqueta"><?= e($s['ciudad']) ?></p>
            <h3><?= e($s['nombre_sucursal']) ?></h3>
            <p><i class="fa fa-map-marker-alt"></i> <?= e($s['direccion']) ?>, <?= e($s['ciudad']) ?></p>
            <?php if ($s['telefono']): ?><p><i class="fa fa-phone"></i> <a href="tel:<?= e(preg_replace('/[^0-9+]/', '', $s['telefono'])) ?>"><?= e($s['telefono']) ?></a></p><?php endif; ?>
            <?php if ($s['email']): ?><p><i class="fa fa-envelope"></i> <a href="mailto:<?= e($s['email']) ?>"><?= e($s['email']) ?></a></p><?php endif; ?>
          </article>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </section>
</main>
<?php include 'parts/pie.php'; ?>
