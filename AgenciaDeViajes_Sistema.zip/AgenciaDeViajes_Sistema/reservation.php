<?php
date_default_timezone_set('America/Mazatlan');
require_once __DIR__ . '/config/BD.php';
require_once __DIR__ . '/config/Auth.php';
sesion();

$idClienteSesion = clienteActual();
if (!$idClienteSesion) {
    if ($_SERVER['REQUEST_METHOD'] === 'GET' && !empty($_SERVER['QUERY_STRING'])) {
        $_SESSION['reserva_qs'] = $_SERVER['QUERY_STRING'];   // recordar destino/fecha elegidos
    }
    irA('login.php?volver=reservation.php');
}
if (!empty($_SESSION['reserva_qs'])) {
    if ($_SERVER['REQUEST_METHOD'] === 'GET' && !$_GET) { parse_str($_SESSION['reserva_qs'], $_GET); }
    unset($_SESSION['reserva_qs']);
}

function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function pesos($n): string { return '$' . number_format((float)$n, 2, '.', ','); }
function fechaValida(string $f): ?DateTimeImmutable {
    $d = DateTimeImmutable::createFromFormat('!Y-m-d', $f);
    return ($d && $d->format('Y-m-d') === $f) ? $d : null;
}
function cantidad(string $tipo, int $personas, int $dias): int {
    return in_array($tipo, ['hotel', 'auto'], true) ? $dias : $personas;
}
$unidad = ['vuelo' => 'por persona', 'tour' => 'por persona', 'hotel' => 'por noche', 'auto' => 'por día'];

if (empty($_SESSION['csrf'])) { $_SESSION['csrf'] = bin2hex(random_bytes(32)); }
$listo = 0;
if (!empty($_GET['listo']) && isset($_SESSION['reserva_ok'])) {
    $listo = (int)$_SESSION['reserva_ok'];
    unset($_SESSION['reserva_ok']);
}

$errores = [];
try {
    $destinos = db()->query("SELECT ID_destino, nombre, pais, duracion_dias FROM destino WHERE activo = 1 ORDER BY nombre")->fetchAll();
    $servicios = db()->query(
        "SELECT ID_servicio, ID_destino, tipo_servicio, nombre_servicio, descripcion, precio_unitario, proveedor
           FROM servicios WHERE activo = 1 AND ID_destino IS NOT NULL
          ORDER BY ID_destino, FIELD(tipo_servicio,'vuelo','hotel','tour','auto'), nombre_servicio"
    )->fetchAll();
} catch (PDOException $ex) {
    error_log('reservation.php catálogo: ' . $ex->getMessage());
    $destinos = $servicios = [];
    $errores[] = 'No pudimos cargar los destinos. Inténtalo de nuevo en unos minutos.';
}
$destPorId = array_column($destinos, null, 'ID_destino');
$servPorId = array_column($servicios, null, 'ID_servicio');

$v = [
    'nombre' => '', 'apellido' => '', 'email' => '', 'telefono' => '',
    'destino' => (int)($_GET['destino'] ?? 0),
    'inicio' => (string)($_GET['fecha'] ?? ''),
    'fin' => '',
    'personas' => max(1, min(10, (int)($_GET['personas'] ?? 2))),
    'servicios' => [],
];

$cliente = null;
try {
    $st = db()->prepare('SELECT nombre, apellido, email, telefono FROM clientes WHERE ID_cliente = ?');
    $st->execute([$idClienteSesion]);
    $cliente = $st->fetch() ?: null;
} catch (PDOException $ex) {
    error_log('reservation.php cliente: ' . $ex->getMessage());
    http_response_code(500);
    exit('No pudimos cargar tu cuenta. Inténtalo de nuevo más tarde.');
}
if (!$cliente) {   // la cuenta ya no existe
    unset($_SESSION['cliente_id'], $_SESSION['cliente_nombre']);
    irA('login.php?volver=reservation.php');
}
$v['nombre'] = $cliente['nombre'];
$v['apellido'] = $cliente['apellido'];
$v['email'] = $cliente['email'];
$v['telefono'] = (string)$cliente['telefono'];  

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$errores) {
    foreach (['nombre', 'apellido', 'email', 'telefono', 'inicio', 'fin'] as $k) {
        $v[$k] = trim((string)($_POST[$k] ?? ''));
    }
    $v['destino'] = (int)($_POST['destino'] ?? 0);
    $v['personas'] = (int)($_POST['personas'] ?? 0);
    $v['servicios'] = array_values(array_unique(array_map('intval', (array)($_POST['servicios'] ?? []))));
    $v['nombre'] = $cliente['nombre'];       // los datos personales siempre vienen de la cuenta
    $v['apellido'] = $cliente['apellido'];
    $v['email'] = $cliente['email'];
    $v['telefono'] = (string)$cliente['telefono'];
    }

    if ($v['nombre'] === '' || strlen($v['nombre']) > 100)     { $errores[] = 'Escribe tu nombre.'; }
    if ($v['apellido'] === '' || strlen($v['apellido']) > 100) { $errores[] = 'Escribe tu apellido.'; }
    if (!filter_var($v['email'], FILTER_VALIDATE_EMAIL) || strlen($v['email']) > 100) { $errores[] = 'Escribe un correo electrónico válido.'; }
    if ($v['telefono'] !== '' && !preg_match('/^[0-9 +()\-]{7,20}$/', $v['telefono'])) { $errores[] = 'El teléfono solo puede llevar números, espacios, + y guiones.'; }
    if ($v['personas'] < 1 || $v['personas'] > 10) { $errores[] = 'El número de personas debe estar entre 1 y 10.'; }

    $ini = $fin = null;
    if (!isset($destPorId[$v['destino']])) {
        $errores[] = 'Elige un destino.';
    } else {
        $ini = fechaValida($v['inicio']);
        if (!$ini || $ini < new DateTimeImmutable('today')) {
            $errores[] = 'Elige una fecha de salida válida (hoy o posterior).';
            $ini = null;
        } elseif ($v['fin'] === '') {
            $fin = $ini->modify('+' . (int)$destPorId[$v['destino']]['duracion_dias'] . ' days');
        } else {
            $fin = fechaValida($v['fin']);
            if (!$fin || $fin <= $ini) { $errores[] = 'La fecha de regreso debe ser posterior a la de salida.'; $fin = null; }
        }
        if (!$v['servicios']) {
            $errores[] = 'Elige al menos un servicio para tu viaje.';
        } else {
            foreach ($v['servicios'] as $idS) {
                if (!isset($servPorId[$idS]) || (int)$servPorId[$idS]['ID_destino'] !== $v['destino']) {
                    $errores[] = 'Alguno de los servicios elegidos no corresponde al destino.';
                    break;
                }
            }
        }
    }

    if (!$errores && $ini && $fin) {
        $pdo = db();
        try {
            $pdo->beginTransaction();

            $idSuc = $pdo->query("SELECT ID_sucursales FROM sucursales WHERE nombre_sucursal = 'En línea' LIMIT 1")->fetchColumn();
            if (!$idSuc) { throw new RuntimeException('Falta la sucursal "En línea" (¿ejecutaste la migración?).'); }

            if ($cliente) {
                $idCliente = $idClienteSesion; 
            }

            $dias = max(1, (int)$ini->diff($fin)->days);
            $total = 0.0;
            $lineas = [];
            foreach ($v['servicios'] as $idS) {
                $s = $servPorId[$idS];
                $sub = round((float)$s['precio_unitario'] * cantidad($s['tipo_servicio'], $v['personas'], $dias), 2);
                $total += $sub;
                $lineas[] = [$idS, $sub];
            }

            $st = $pdo->prepare("INSERT INTO reservas (ID_cliente, ID_sucursales, fecha_reserva, num_personas, estado, total_pagar)
                                 VALUES (?, ?, CURDATE(), ?, 'pendiente', ?)");
            $st->execute([$idCliente, $idSuc, $v['personas'], round($total, 2)]);
            $idReserva = (int)$pdo->lastInsertId();

            $st = $pdo->prepare('INSERT INTO detalle_reservas (ID_reserva, ID_servicio, ID_destino, fecha_inicio, fecha_fin, subtotal)
                                 VALUES (?, ?, ?, ?, ?, ?)');
            foreach ($lineas as [$idS, $sub]) {
                $st->execute([$idReserva, $idS, $v['destino'], $ini->format('Y-m-d'), $fin->format('Y-m-d'), $sub]);
            }

            $pdo->commit();
            $_SESSION['reserva_ok'] = $idReserva;
            $_SESSION['csrf'] = bin2hex(random_bytes(32));
            header('Location: reservation.php?listo=1');
            exit;
        } catch (Throwable $ex) {
            if ($pdo->inTransaction()) { $pdo->rollBack(); }
            error_log('reservation.php guardar: ' . $ex->getMessage());
            $errores[] = 'No pudimos registrar tu reservación. Inténtalo de nuevo o llámanos.';
        }
  }

$titulo = 'Travel 360 - Reservaciones';
$css_extra = 'assets/css/reservation.css';
include 'parts/head.php';
include 'parts/header.php';
?>
<main>
  <section class="page-head">
    <div class="wrap">
      <p class="etiqueta">Reservaciones</p>
      <h1>Reserva tu viaje</h1>
      <p class="lead">Elige tu destino y los servicios que necesitas. Un asesor revisará tu solicitud.</p>
    </div>
  </section>

  <section class="wrap reserva-seccion">
  <?php if ($listo): ?>
    <div class="caja exito">
      <i class="fa fa-circle-check"></i>
      <h2>¡Reservación registrada!</h2>
      <p>Tu número de reservación es <strong>#<?= $listo ?></strong>. Quedó como <strong>pendiente</strong> mientras un asesor de 360 Travel la revisa para confirmarla.</p>
      <a href="index.php" class="btn btn-teal">Volver al inicio</a>
      <?php if ($idClienteSesion): ?><a href="myReservation.php" class="btn btn-linea">Ver mis reservaciones</a><?php endif; ?>
    </div>
  <?php else: ?>
    <?php if ($errores): ?>
      <div class="aviso aviso-error" role="alert">
        <strong>Revisa lo siguiente:</strong>
        <ul><?php foreach ($errores as $m): ?><li><?= e($m) ?></li><?php endforeach; ?></ul>
      </div>
    <?php endif; ?>

    <form id="reserva" class="reserva-grid" method="post" action="reservation.php">
      <input type="hidden" name="csrf" value="<?= e($_SESSION['csrf']) ?>">

      <div class="reserva-campos">
        <fieldset class="caja">
          <legend>1 · Tu viaje</legend>
          <div class="campos">
            <label class="ancho">Destino
              <select name="destino" required>
                <option value="">Elige un destino</option>
                <?php foreach ($destinos as $d): ?>
                  <option value="<?= (int)$d['ID_destino'] ?>" data-dias="<?= (int)$d['duracion_dias'] ?>" <?= $v['destino'] === (int)$d['ID_destino'] ? 'selected' : '' ?>>
                    <?= e($d['nombre']) ?>, <?= e($d['pais']) ?>
                  </option>
                <?php endforeach; ?>
              </select>
            </label>
            <label>Fecha de salida
              <input type="date" name="inicio" min="<?= date('Y-m-d') ?>" value="<?= e($v['inicio']) ?>" required>
            </label>
            <label>Fecha de regreso <small>(opcional)</small>
              <input type="date" name="fin" min="<?= date('Y-m-d') ?>" value="<?= e($v['fin']) ?>">
            </label>
            <label>Personas
              <select name="personas">
                <?php for ($i = 1; $i <= 10; $i++): ?>
                  <option value="<?= $i ?>" <?= $v['personas'] === $i ? 'selected' : '' ?>><?= $i ?></option>
                <?php endfor; ?>
              </select>
            </label>
          </div>
        </fieldset>

        <fieldset class="caja">
          <legend>2 · Servicios</legend>
          <p id="sin-servicios" class="suave" <?= isset($destPorId[$v['destino']]) ? 'hidden' : '' ?>>Elige un destino para ver los servicios disponibles.</p>
          <?php foreach ($servicios as $s):
              $visible = $v['destino'] === (int)$s['ID_destino'];
              $marcado = $visible && in_array((int)$s['ID_servicio'], $v['servicios'], true); ?>
            <label class="servicio" data-destino="<?= (int)$s['ID_destino'] ?>" data-tipo="<?= e($s['tipo_servicio']) ?>" data-precio="<?= e($s['precio_unitario']) ?>" <?= $visible ? '' : 'hidden' ?>>
              <input type="checkbox" name="servicios[]" value="<?= (int)$s['ID_servicio'] ?>" <?= $marcado ? 'checked' : '' ?>>
              <span class="servicio-info">
                <strong><?= e($s['nombre_servicio']) ?></strong>
                <small><?= e(ucfirst($s['tipo_servicio'])) ?> · <?= e($s['descripcion']) ?> · <?= e($s['proveedor']) ?></small>
              </span>
              <span class="servicio-precio"><?= pesos($s['precio_unitario']) ?><small><?= $unidad[$s['tipo_servicio']] ?? '' ?></small></span>
            </label>
          <?php endforeach; ?>
        </fieldset>

        <fieldset class="caja">
          <legend>3 · Tus datos</legend>
          <p>Reservarás como <strong><?= e($cliente['nombre'] . ' ' . $cliente['apellido']) ?></strong> (<?= e($cliente['email']) ?>). Podrás ver esta reservación en <a href="myReservation.php">Mis reservaciones</a>.</p>
        </fieldset>
      </div>

      <aside class="caja resumen">
        <h3>Resumen</h3>
        <p class="suave">Total estimado</p>
        <p class="total" id="total">$0.00</p>
        <p class="suave nota">Vuelos y tours se cobran por persona; hoteles y autos, por noche o día. El total final lo confirma un asesor.</p>
        <button class="btn btn-brasa" type="submit">Enviar reservación</button>
      </aside>
    </form>
  <?php endif; ?>
  </section>
</main>

<script>
(function () {
  var form = document.getElementById('reserva');
  if (!form) return;
  var destino = form.destino, ini = form.inicio, fin = form.fin, pers = form.personas;
  var servs = form.querySelectorAll('.servicio');
  var vacio = document.getElementById('sin-servicios'), total = document.getElementById('total');

  function dur() { var o = destino.options[destino.selectedIndex]; return o && o.dataset.dias ? +o.dataset.dias : 5; }
  function dias() {
    if (!ini.value) return dur();
    var a = new Date(ini.value), b = fin.value ? new Date(fin.value) : null;
    return b && b > a ? Math.round((b - a) / 864e5) : dur();
  }
  function pesos(n) { return '$' + n.toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
  function sugerirFin() {
    if (fin.dataset.manual || !ini.value) return;
    var f = new Date(ini.value); f.setDate(f.getDate() + dur());
    fin.value = f.toISOString().slice(0, 10);
  }
  function actualizar() {
    var d = dias(), p = +pers.value || 1, t = 0, visibles = 0;
    servs.forEach(function (s) {
      var mostrar = s.dataset.destino === destino.value;
      var chk = s.querySelector('input');
      s.hidden = !mostrar;
      if (!mostrar) { chk.checked = false; return; }
      visibles++;
      if (chk.checked) t += parseFloat(s.dataset.precio) * ((s.dataset.tipo === 'hotel' || s.dataset.tipo === 'auto') ? d : p);
    });
    vacio.hidden = visibles > 0;
    total.textContent = pesos(t);
  }

  form.addEventListener('change', function (e) {
    if (e.target === fin) fin.dataset.manual = '1';
    if (e.target === destino || e.target === ini) sugerirFin();
    actualizar();
  });
  if (fin.value) fin.dataset.manual = '1';
  actualizar();
})();
</script>
<?php include 'parts/pie.php'; ?>