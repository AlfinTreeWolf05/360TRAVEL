<?php
require_once __DIR__ . '/config/BD.php'; 
require_once __DIR__ . '/config/Auth.php';

$fotos = ['country-1.jpg', 'country-02.jpg', 'country-03.jpg', 'banner-04.jpg'];
$unidad = ['vuelo' => 'por persona', 'tour' => 'por persona', 'hotel' => 'por noche', 'auto' => 'por día'];
$tipos = ['vuelo' => 'Vuelos', 'hotel' => 'Hoteles', 'tour' => 'Tours', 'auto' => 'Autos'];

$id = (int)($_GET['id'] ?? 0);
$q = trim((string)($_GET['q'] ?? ''));
$fPais = trim((string)($_GET['pais'] ?? ''));
$fTipo = (string)($_GET['tipo'] ?? '');
if (!isset($tipos[$fTipo])) { $fTipo = ''; }

$d = null; $grupos = []; $lista = []; $paises = []; $error = false;
try {
    if ($id) {
        $st = db()->prepare('SELECT ID_destino, nombre, pais, descripcion, imagen, precio_desde, duracion_dias FROM destino WHERE ID_destino = ? AND activo = 1');
        $st->execute([$id]);
        $d = $st->fetch() ?: null;
        if ($d) {
            $st = db()->prepare("SELECT tipo_servicio, nombre_servicio, descripcion, precio_unitario, proveedor FROM servicios
                                  WHERE ID_destino = ? AND activo = 1
                                  ORDER BY FIELD(tipo_servicio,'vuelo','hotel','tour','auto'), nombre_servicio");
            $st->execute([$id]);
            foreach ($st->fetchAll() as $s) { $grupos[$s['tipo_servicio']][] = $s; }
        }
    } else {
        $paises = db()->query('SELECT DISTINCT pais FROM destino WHERE activo = 1 ORDER BY pais')->fetchAll(PDO::FETCH_COLUMN);
        $sql = 'SELECT d.ID_destino, d.nombre, d.pais, d.descripcion, d.imagen, d.precio_desde, d.duracion_dias FROM destino d WHERE d.activo = 1';
        $p = [];
        if ($q !== '') { $sql .= ' AND (d.nombre LIKE ? OR d.pais LIKE ?)'; $like = '%' . addcslashes($q, '%_\\') . '%'; $p[] = $like; $p[] = $like; }
        if ($fPais !== '') { $sql .= ' AND d.pais = ?'; $p[] = $fPais; }
        if ($fTipo !== '') { $sql .= ' AND EXISTS (SELECT 1 FROM servicios s WHERE s.ID_destino = d.ID_destino AND s.activo = 1 AND s.tipo_servicio = ?)'; $p[] = $fTipo; }
        $st = db()->prepare($sql . ' ORDER BY d.nombre');
        $st->execute($p);
        $lista = $st->fetchAll();
    }
} catch (PDOException $ex) {
    error_log('destinations.php: ' . $ex->getMessage());
    $error = true;
}
if ($id && !$d && !$error) { http_response_code(404); }

$titulo = $d ? 'Travel 360 - ' . $d['nombre'] : 'Travel 360 - Destinos';
$css_extra = 'assets/css/pages.css';
include 'parts/head.php';
include 'parts/header.php';
?>
<main>
<?php if ($id): ?>
  <?php if ($error): ?>
    <section class="wrap seccion"><p class="vacio">No pudimos cargar el destino. Inténtalo más tarde.</p></section>
  <?php elseif (!$d): ?>
    <section class="wrap seccion"><p class="vacio">Ese destino no existe o ya no está disponible. <a href="destinations.php">Ver todos los destinos</a></p></section>
  <?php else: ?>
    <section class="page-head">
      <div class="wrap">
        <p class="etiqueta"><a href="destinations.php">← Todos los destinos</a></p>
        <h1><?= e($d['nombre']) ?></h1>
        <p class="lead"><?= e($d['pais']) ?> · <?= (int)$d['duracion_dias'] ?> días sugeridos</p>
      </div>
    </section>
    <section class="wrap detalle">
      <div>
        <img class="detalle-img" src="<?= e(urlImagenDestino($d['imagen'], $fotos[$id % count($fotos)])) ?>" alt="<?= e($d['nombre']) ?>">
        <p class="detalle-desc"><?= e($d['descripcion']) ?></p>
        <h2>Servicios disponibles</h2>
        <?php if (!$grupos): ?><p class="suave">Pronto agregaremos servicios para este destino.</p><?php endif; ?>
        <?php foreach ($grupos as $tipo => $items): ?>
          <h3><?= e($tipos[$tipo] ?? ucfirst($tipo)) ?></h3>
          <ul class="servicios-lista">
            <?php foreach ($items as $s): ?>
              <li>
                <span><strong><?= e($s['nombre_servicio']) ?></strong><small><?= e($s['descripcion']) ?> · <?= e($s['proveedor']) ?></small></span>
                <span class="sprecio"><?= pesos($s['precio_unitario']) ?><small><?= $unidad[$tipo] ?? '' ?></small></span>
              </li>
            <?php endforeach; ?>
          </ul>
        <?php endforeach; ?>
      </div>
      <aside class="caja lateral">
        <p class="suave">Desde</p>
        <p class="gran"><?= $d['precio_desde'] > 0 ? pesos($d['precio_desde']) : 'Consultar' ?></p>
        <a href="reservation.php?destino=<?= (int)$d['ID_destino'] ?>" class="btn btn-brasa">Reservar este destino</a>
      </aside>
    </section>
  <?php endif; ?>
<?php else: ?>
  <section class="page-head">
    <div class="wrap">
      <p class="etiqueta">Destinos</p>
      <h1>¿A dónde quieres ir?</h1>
      <p class="lead">Explora nuestros destinos y los servicios que incluye cada uno.</p>
    </div>
  </section>
  <section class="wrap seccion-lista">
    <form class="buscador filtros" method="get" action="destinations.php">
      <label>Buscar <input type="search" name="q" value="<?= e($q) ?>" placeholder="Ciudad o país"></label>
      <label>País
        <select name="pais"><option value="">Todos</option>
          <?php foreach ($paises as $p): ?><option value="<?= e($p) ?>" <?= $fPais === $p ? 'selected' : '' ?>><?= e($p) ?></option><?php endforeach; ?>
        </select>
      </label>
      <label>Con servicio de
        <select name="tipo"><option value="">Cualquiera</option>
          <?php foreach ($tipos as $k => $t): ?><option value="<?= $k ?>" <?= $fTipo === $k ? 'selected' : '' ?>><?= $t ?></option><?php endforeach; ?>
        </select>
      </label>
      <button class="btn btn-teal" type="submit">Filtrar</button>
    </form>
    <?php if ($error): ?>
      <p class="vacio">No pudimos cargar los destinos. Inténtalo más tarde.</p>
    <?php elseif (!$lista): ?>
      <p class="vacio">No encontramos destinos con esos filtros. <a href="destinations.php">Ver todos</a></p>
    <?php else: ?>
      <div class="tarjetas">
        <?php foreach ($lista as $i => $x): ?>
          <article class="tarjeta">
            <a class="tarjeta-img" href="destinations.php?id=<?= (int)$x['ID_destino'] ?>">
              <img src="<?= e(urlImagenDestino($x['imagen'], $fotos[$i % count($fotos)])) ?>" alt="<?= e($x['nombre']) ?>" loading="lazy">
              <span class="chip"><?= e($x['pais']) ?></span>
            </a>
            <div class="tarjeta-cuerpo">
              <h3><?= e($x['nombre']) ?></h3>
              <p class="meta"><?= e($x['descripcion']) ?></p>
              <div class="tarjeta-pie">
                <p class="precio"><small>Desde</small> <?= $x['precio_desde'] > 0 ? pesos($x['precio_desde']) : 'Consultar' ?></p>
                <a href="destinations.php?id=<?= (int)$x['ID_destino'] ?>" class="btn btn-linea btn-sm">Ver detalle</a>
              </div>
            </div>
          </article>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </section>
<?php endif; ?>
</main>
<?php include 'parts/pie.php'; ?>