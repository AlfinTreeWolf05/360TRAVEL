<?php
require_once __DIR__ . '/config/BD.php';   // si tu archivo se llama BD.php, cambia este nombre
require_once __DIR__ . '/config/Auth.php';
sesion();

$permitidas = ['myReservation.php', 'reservation.php'];
$pedida = (string)($_GET['volver'] ?? $_POST['volver'] ?? '');
$volver = in_array($pedida, $permitidas, true) ? $pedida : 'myReservation.php';
if (clienteActual()) { irA($volver); }

$v = ['nombre' => '', 'apellido' => '', 'email' => '', 'telefono' => ''];
$errores = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($v as $k => $_) { $v[$k] = trim((string)($_POST[$k] ?? '')); }
    $clave = (string)($_POST['password'] ?? '');
    $clave2 = (string)($_POST['password2'] ?? '');

    if (!csrfOk()) { $errores[] = 'Tu sesión expiró. Recarga la página e inténtalo de nuevo.'; }
    if ($v['nombre'] === '' || strlen($v['nombre']) > 100)     { $errores[] = 'Escribe tu nombre.'; }
    if ($v['apellido'] === '' || strlen($v['apellido']) > 100) { $errores[] = 'Escribe tu apellido.'; }
    if (!filter_var($v['email'], FILTER_VALIDATE_EMAIL) || strlen($v['email']) > 100) { $errores[] = 'Escribe un correo electrónico válido.'; }
    if ($v['telefono'] !== '' && !preg_match('/^[0-9 +()\-]{7,20}$/', $v['telefono'])) { $errores[] = 'El teléfono no es válido.'; }
    if (strlen($clave) < 8 || strlen($clave) > 72) { $errores[] = 'La contraseña debe tener entre 8 y 72 caracteres.'; }
    if ($clave !== $clave2) { $errores[] = 'Las contraseñas no coinciden.'; }

    if (!$errores) {
        $yaExiste = 'Ese correo ya tiene un registro en la agencia. Si ya reservaste con nosotros y quieres activar tu cuenta, comunícate con una sucursal.';
        try {
            $st = db()->prepare('SELECT 1 FROM clientes WHERE email = ?');
            $st->execute([$v['email']]);
            if ($st->fetchColumn()) {
                $errores[] = $yaExiste;
            } else {
                $st = db()->prepare('INSERT INTO clientes (nombre, apellido, telefono, email, password_hash) VALUES (?, ?, ?, ?, ?)');
                $st->execute([$v['nombre'], $v['apellido'], $v['telefono'] !== '' ? $v['telefono'] : null, $v['email'], password_hash($clave, PASSWORD_DEFAULT)]);
                entrar((int)db()->lastInsertId(), $v['nombre']);
                irA($volver);
            }
        } catch (PDOException $ex) {
            error_log('register.php: ' . $ex->getMessage());
            $errores[] = ($ex->errorInfo[1] ?? 0) == 1062 ? $yaExiste : 'No pudimos crear tu cuenta. Inténtalo más tarde.';
        }
    }
}

$titulo = 'Travel 360 - Crear cuenta';
$css_extra = 'assets/css/pages.css';
include 'parts/head.php';
include 'parts/header.php';
?>
<main class="wrap auth-seccion">
  <div class="caja auth-card">
    <h1>Crear cuenta</h1>
    <?php if ($errores): ?>
      <div class="aviso aviso-error" role="alert"><ul><?php foreach ($errores as $m): ?><li><?= e($m) ?></li><?php endforeach; ?></ul></div>
    <?php endif; ?>
    <form method="post" action="register.php" class="campos una-col">
      <input type="hidden" name="csrf" value="<?= e(csrf()) ?>">
      <input type="hidden" name="volver" value="<?= e($volver) ?>">
      <label>Nombre <input type="text" name="nombre" maxlength="100" value="<?= e($v['nombre']) ?>" autocomplete="given-name" required></label>
      <label>Apellido <input type="text" name="apellido" maxlength="100" value="<?= e($v['apellido']) ?>" autocomplete="family-name" required></label>
      <label>Correo electrónico <input type="email" name="email" maxlength="100" value="<?= e($v['email']) ?>" autocomplete="email" required></label>
      <label>Teléfono <small>(opcional)</small> <input type="tel" name="telefono" maxlength="20" value="<?= e($v['telefono']) ?>" autocomplete="tel"></label>
      <label>Contraseña <small>(mínimo 8 caracteres)</small> <input type="password" name="password" minlength="8" maxlength="72" autocomplete="new-password" required></label>
      <label>Repite la contraseña <input type="password" name="password2" minlength="8" maxlength="72" autocomplete="new-password" required></label>
      <button class="btn btn-brasa" type="submit">Crear cuenta</button>
    </form>
    <p class="suave centro">¿Ya tienes cuenta? <a href="login.php?volver=<?= e($volver) ?>">Inicia sesión</a></p>
  </div>
</main>