<?php
require_once __DIR__ . '/config/BD.php'; 
require_once __DIR__ . '/config/Auth.php';
sesion();

$permitidas = ['myReservation.php', 'reservation.php'];
$pedida = (string)($_GET['volver'] ?? $_POST['volver'] ?? '');
$volver = in_array($pedida, $permitidas, true) ? $pedida : 'myReservation.php';   // lista blanca: evita redirecciones abiertas
if (clienteActual()) { irA($volver); }

$error = '';
$email = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim((string)($_POST['email'] ?? ''));
    $clave = (string)($_POST['password'] ?? '');
    if (!csrfOk()) {
        $error = 'Tu sesión expiró. Recarga la página e inténtalo de nuevo.';
    } elseif (($_SESSION['bloqueo'] ?? 0) > time()) {
        $error = 'Demasiados intentos. Espera unos minutos e inténtalo de nuevo.';
    } else {
        try {
            $st = db()->prepare('SELECT ID_cliente, nombre, password_hash FROM clientes WHERE email = ?');
            $st->execute([$email]);
            $c = $st->fetch();
            $hash = ($c && $c['password_hash']) ? $c['password_hash'] : password_hash('x', PASSWORD_DEFAULT); // tiempo parejo exista o no el correo
            if (password_verify($clave, $hash) && $c && $c['password_hash']) {
                unset($_SESSION['intentos'], $_SESSION['bloqueo']);
                entrar((int)$c['ID_cliente'], $c['nombre']);
                irA($volver);
            }
            $_SESSION['intentos'] = ($_SESSION['intentos'] ?? 0) + 1;
            if ($_SESSION['intentos'] >= 5) { $_SESSION['bloqueo'] = time() + 300; $_SESSION['intentos'] = 0; }
            $error = 'Correo o contraseña incorrectos.';   // mismo mensaje en cualquier fallo
        } catch (PDOException $ex) {
            error_log('login.php: ' . $ex->getMessage());
            $error = 'No pudimos iniciar sesión. Inténtalo más tarde.';
        }
    }
}

$titulo = 'Travel 360 - Iniciar sesión';
$css_extra = 'assets/css/pages.css';
include 'parts/head.php';
include 'parts/header.php';
?>
<main class="acceso">
  <div class="acceso-caja">
    <aside class="acceso-lado">
      <p class="etiqueta etiqueta-clara">Mi cuenta</p>
      <h1>Qué bueno verte de nuevo</h1>
      <p class="acceso-intro">Entra para seguir tu viaje desde el primer paso hasta el último día.</p>
      <ul class="acceso-lista">
        <li><i class="fa fa-suitcase-rolling" aria-hidden="true"></i> Revisa el estado de tus reservaciones</li>
        <li><i class="fa fa-receipt" aria-hidden="true"></i> Consulta tus pagos y facturas</li>
        <li><i class="fa fa-calendar-xmark" aria-hidden="true"></i> Cancela reservaciones pendientes</li>
      </ul>
    </aside>

    <section class="acceso-form">
      <h2>Iniciar sesión</h2>
      <p class="suave">Usa el correo con el que te registraste.</p>

      <?php if ($error): ?><div class="aviso aviso-error" role="alert"><?= e($error) ?></div><?php endif; ?>
      <?php if ($volver === 'reservation.php' && !$error): ?><div class="aviso aviso-ok" role="status">Inicia sesión o crea una cuenta para hacer tu reservación.</div><?php endif; ?>

      <form method="post" action="login.php" class="acceso-campos" novalidate>
        <input type="hidden" name="csrf" value="<?= e(csrf()) ?>">
        <input type="hidden" name="volver" value="<?= e($volver) ?>">

        <label class="campo">
          <span>Correo electrónico</span>
          <span class="campo-in">
            <i class="fa fa-envelope" aria-hidden="true"></i>
            <input type="email" name="email" value="<?= e($email) ?>" placeholder="tucorreo@ejemplo.com" autocomplete="email" required autofocus>
          </span>
        </label>

        <label class="campo">
          <span>Contraseña</span>
          <span class="campo-in">
            <i class="fa fa-lock" aria-hidden="true"></i>
            <input type="password" name="password" id="clave" placeholder="Tu contraseña" autocomplete="current-password" required>
          </span>
        </label>

        <button class="btn btn-brasa btn-block" type="submit">Entrar</button>
      </form>

      <p class="acceso-pie">¿Aún no tienes cuenta? <a href="register.php?volver=<?= e($volver) ?>">Crea una gratis</a></p>
    </section>
  </div>
</main>
<?php include 'parts/pie.php'; ?>