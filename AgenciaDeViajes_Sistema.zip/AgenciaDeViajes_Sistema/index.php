<?php
require_once __DIR__ . '/config/BD.php';

// Destinos activos desde MySQL. Si `imagen` está vacía se usa una foto por defecto.
$fotos = ['country-1.png'];
$destinos = [];
try {
    $filas = db()->query("SELECT ID_destino, nombre, pais, imagen, precio_desde, duracion_dias
                            FROM destino WHERE activo = 1 ORDER BY ID_destino LIMIT 8")->fetchAll();
    foreach ($filas as $i => $f) {
        $destinos[] = [
            'id' => (int)$f['ID_destino'], 'nombre' => $f['nombre'], 'region' => $f['pais'],
            'img' => $f['imagen'] ?: $fotos[$i % count($fotos)],
            'dias' => (int)$f['duracion_dias'], 'precio' => (float)$f['precio_desde'],
        ];
    }
} catch (PDOException $e) {
    error_log('index.php destinos: ' . $e->getMessage());
}
$precios = array_filter(array_column($destinos, 'precio'));
$precioMin = $precios ? min($precios) : 0;
$pesos = fn($n) => '$' . number_format($n, 0, '.', ',');

$titulo = 'Travel 360 - Inicio';
include 'parts/head.php';
include 'parts/header.php';
?>
<main>
  <!-- HERO -->
  <section class="hero">
    <div class="wrap hero-in">
      <div class="hero-texto">
        <h1>El mundo, <em>de 0 a 360</em> grados.</h1>
        <p class="lead">Armamos tu viaje completo, desde el vuelo hasta el último día, para que solo te ocupes de disfrutarlo.</p>
        <div class="hero-botones">
          <a href="reservation.php" class="btn btn-brasa">Reservar ahora</a>
          <a href="deals.php" class="btn btn-linea">Ver ofertas</a>
        </div>
      </div>
      <div class="hero-foto">
        <img src="http://127.0.0.1:8000/storage/destinos/RLS05RgU2GUr3SBDLmOY4wSOTihsIM7vInQpBNAj.jpg" alt="Destino destacado de 360 Travel">
        <div class="sello"><span>Desde</span><strong><?= $pesos($precioMin) ?></strong><span>MXN por persona</span></div>
      </div>
    </div>
  </section>

  <!-- BUSCADOR -->
  <section class="wrap buscador-caja">
    <form class="buscador" action="reservation.php" method="get">
      <label>Destino
        <select name="destino" required>
          <option value="">Elige un destino</option>
          <?php foreach ($destinos as $d): ?>
            <option value="<?= $d['id'] ?>"><?= htmlspecialchars($d['nombre']) ?></option>
          <?php endforeach; ?>
        </select>
      </label>
      <label>Fecha de salida <input type="date" name="fecha" min="<?= date('Y-m-d') ?>"></label>
      <label>Personas
        <select name="personas">
          <option>1</option><option selected>2</option><option>3</option><option>4</option><option>5+</option>
        </select>
      </label>
      <button class="btn btn-teal" type="submit">Buscar viaje</button>
    </form>
  </section>

  <!-- DESTINOS -->
  <section class="seccion wrap">
    <p class="etiqueta">Destinos populares</p>
    <h2>¿A dónde quieres ir?</h2>
    <div class="tarjetas">
      <?php foreach ($destinos as $d): ?>
        <article class="tarjeta">
          <div class="tarjeta-img">
            <img src="<?= htmlspecialchars(urlImagenDestino($d['img'])) ?>" alt="<?= htmlspecialchars($d['nombre']) ?>" loading="lazy">
            <span class="chip"><?= htmlspecialchars($d['region']) ?></span>
          </div>
          <div class="tarjeta-cuerpo">
            <h3><?= htmlspecialchars($d['nombre']) ?></h3>
            <p class="meta"><i class="fa fa-clock"></i> <?= $d['dias'] ?> días · <?= htmlspecialchars($d['region']) ?></p>
            <div class="tarjeta-pie">
              <p class="precio"><small>Desde</small> <?= $pesos($d['precio']) ?></p>
              <a href="reservation.php?destino=<?= $d['id'] ?>" class="btn btn-brasa btn-sm">Reservar</a>
            </div>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  </section>

  <!-- POR QUÉ ELEGIRNOS -->
  <section class="razones">
    <div class="wrap">
      <p class="etiqueta etiqueta-clara">Por qué 360 Travel</p>
      <h2>Todo el viaje, en un solo lugar</h2>
      <div class="razones-grid">
        <div><i class="fa fa-headset"></i><h3>Atención personalizada</h3><p>Un asesor te acompaña antes, durante y después del viaje.</p></div>
        <div><i class="fa fa-tags"></i><h3>Precios claros</h3><p>Sin cargos ocultos: lo que ves incluido es lo que recibes.</p></div>
        <div><i class="fa fa-credit-card"></i><h3>Pagos flexibles</h3><p>Reserva hoy y paga a tu ritmo, con las opciones que prefieras.</p></div>
      </div>
    </div>
  </section>

  <!-- LLAMADO A LA ACCIÓN -->
  <section class="wrap cta">
    <h2>¿Listo para tu próximo viaje?</h2>
    <p>Cuéntanos a dónde quieres ir y nosotros nos encargamos del resto.</p>
    <a href="reservation.php" class="btn btn-brasa">Hacer una reservación</a>
  </section>
</main>
<?php include 'parts/pie.php'; ?>