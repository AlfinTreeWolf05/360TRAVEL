<?php
    const BD_HOST = 'localhost';
    const BD_NAME = 'agenciadeviajes';
    const BD_USER = 'web360';
    const BD_PWD = 'admin1234';

    function db(): PDO{
        static $pdo = null;
        if ($pdo == null) {
            try {
                $pdo = new PDO(
                    'mysql:host=' . BD_HOST . ';dbname=' . BD_NAME . ';charset=utf8mb4',
                    BD_USER,
                    BD_PWD,
                    [
                        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                        PDO::ATTR_EMULATE_PREPARES => false,
                    ]
                );
            } catch (PDOException $e) {
                error_log('Error de conexión: ' . $e->getMessage());
                http_response_code(500);
                exit('No pudimos conectar al servidor. Intentalo de nuevo más tarde.');
            }
        }
        return $pdo;
    }

    function urlImagenDestino(?string $imagen, string $fallback = 'country-1.png'): string
    {
        if (empty($imagen)) {
            return 'assets/img/' . $fallback;
        }

        // Imágenes nuevas almacenadas desde Laravel
        if (str_starts_with($imagen, 'destinos/')) {
            return 'http://127.0.0.1:8000/storage/' .
                implode('/', array_map('rawurlencode', explode('/', $imagen)));
        }

        // Imágenes antiguas almacenadas en el sistema PHP
        return 'assets/img/' . $imagen;
    }
?>