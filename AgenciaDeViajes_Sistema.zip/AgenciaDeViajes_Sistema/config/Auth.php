<?php
// Utilidades de sesión y seguridad compartidas por todas las páginas.
function sesion(): void
{
    if (session_status() === PHP_SESSION_NONE) {
        ini_set('session.use_strict_mode', '1');
        session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax', 'secure' => !empty($_SERVER['HTTPS'])]);
        session_start();
    }
}
if (!function_exists('e')) {
    function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
}
if (!function_exists('pesos')) {
    function pesos($n): string { return '$' . number_format((float)$n, 2, '.', ','); }
}
function csrf(): string
{
    sesion();
    if (empty($_SESSION['csrf'])) { $_SESSION['csrf'] = bin2hex(random_bytes(32)); }
    return $_SESSION['csrf'];
}
function csrfOk(): bool
{
    sesion();
    return !empty($_SESSION['csrf']) && hash_equals($_SESSION['csrf'], (string)($_POST['csrf'] ?? ''));
}
function clienteActual(): ?int
{
    sesion();
    return isset($_SESSION['cliente_id']) ? (int)$_SESSION['cliente_id'] : null;
}
function entrar(int $id, string $nombre): void
{
    sesion();
    session_regenerate_id(true);          // evita fijación de sesión
    $_SESSION['cliente_id'] = $id;
    $_SESSION['cliente_nombre'] = $nombre;
}
function irA(string $url)
{
    header('Location: ' . $url);
    exit;
}
function requerirCliente(): int
{
    $id = clienteActual();
    if (!$id) { irA('login.php?volver=myReservation.php'); }
    return $id;
}