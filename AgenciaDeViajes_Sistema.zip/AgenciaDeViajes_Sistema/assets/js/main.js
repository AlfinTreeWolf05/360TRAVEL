(function () {
  var header = document.querySelector('.site-header');
  var btn = document.querySelector('.menu-btn');
  var menu = document.querySelector('.menu');

  // Sombra en el encabezado al hacer scroll
  function alScroll() { header.classList.toggle('con-sombra', window.scrollY > 10); }
  window.addEventListener('scroll', alScroll, { passive: true });
  alScroll();

  // Menú en celular
  btn.addEventListener('click', function () {
    var abierto = menu.classList.toggle('abierto');
    btn.setAttribute('aria-expanded', abierto);
  });

  // Botón "ver contraseña" automático en todos los campos de contraseña
  (function () {
  var svg = function (trazos) {
    return '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" ' +
           'stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + trazos + '</svg>';
  };
  var OJO = svg('<path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z"/><circle cx="12" cy="12" r="3"/>');
  var OJO_TACHADO = svg('<path d="M17.94 17.94A10.94 10.94 0 0 1 12 19C5 19 1 12 1 12a18.5 18.5 0 0 1 5.06-5.94M9.9 4.24A9.1 9.1 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19M14.12 14.12a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/>');

  document.querySelectorAll('input[type="password"]').forEach(function (campo) {
    if (campo.parentNode.querySelector('.ver-clave')) return;   // ya tiene su propio botón

    var caja = document.createElement('span');
    caja.className = 'clave-wrap';
    campo.classList.add('clave-campo');
    campo.parentNode.insertBefore(caja, campo);
    caja.appendChild(campo);

    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'clave-ver';
    btn.setAttribute('aria-label', 'Mostrar contraseña');
    btn.setAttribute('aria-pressed', 'false');
    btn.innerHTML = OJO;
    caja.appendChild(btn);

    btn.addEventListener('click', function () {
      var ver = campo.type === 'password';
      campo.type = ver ? 'text' : 'password';
      btn.setAttribute('aria-pressed', ver);
      btn.setAttribute('aria-label', ver ? 'Ocultar contraseña' : 'Mostrar contraseña');
      btn.innerHTML = ver ? OJO_TACHADO : OJO;
    });
  });
})();
})();

// Modo claro / oscuro (el tema inicial lo pone el script de parts/head.php)
(function () {
  var raiz = document.documentElement;
  var btn = document.querySelector('.tema-btn');
  if (!btn) return;

  function aplicar(tema) {
    var oscuro = tema === 'dark';
    raiz.setAttribute('data-theme', tema);
    btn.setAttribute('aria-pressed', oscuro);
    btn.setAttribute('aria-label', oscuro ? 'Cambiar a modo claro' : 'Cambiar a modo oscuro');
  }
  aplicar(raiz.getAttribute('data-theme') === 'dark' ? 'dark' : 'light');

  btn.addEventListener('click', function () {
    var nuevo = raiz.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    aplicar(nuevo);
    try { localStorage.setItem('tema', nuevo); } catch (e) {}
  });

  // Mientras la persona no elija, se sigue el cambio de tema del sistema
  if (window.matchMedia) {
    var mq = matchMedia('(prefers-color-scheme: dark)');
    var alCambiar = function (e) {
      try { if (localStorage.getItem('tema')) return; } catch (x) {}
      aplicar(e.matches ? 'dark' : 'light');
    };
    if (mq.addEventListener) mq.addEventListener('change', alCambiar);
  }
})();