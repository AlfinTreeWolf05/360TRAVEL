<footer class="site-footer">
  <div class="wrap">
    <p>© <?= date('Y') ?> <strong>360 TRAVEL</strong> Company S.A. de C.V. · Call center 5555-555-5555 · Todos los derechos reservados.</p>
  </div>
</footer>
<script src="assets/js/main.js"></script>
</body>
</html>
