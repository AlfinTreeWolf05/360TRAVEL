<?php require_once __DIR__ . '/../config/Auth.php'; sesion(); ?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script>
    // Aplica el tema guardado (o el del sistema) antes de pintar la página, para que no parpadee
    (function () {
      var t = null;
      try { t = localStorage.getItem('tema'); } catch (e) {}
      if (t !== 'dark' && t !== 'light') { t = window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'; }
      document.documentElement.setAttribute('data-theme', t);
    })();
  </script>
  <title><?= htmlspecialchars($titulo ?? 'Travel 360') ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;700&family=DM+Serif+Display&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/fontawesome.css">
  <link rel="stylesheet" href="assets/css/main.css">
  <?php if (!empty($css_extra)): ?><link rel="stylesheet" href="<?= htmlspecialchars($css_extra) ?>"><?php endif; ?>
  <link rel="stylesheet" href="assets/css/tema.css">
</head>
<body>