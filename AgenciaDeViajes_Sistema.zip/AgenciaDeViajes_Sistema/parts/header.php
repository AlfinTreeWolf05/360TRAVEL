<?php
$actual = basename($_SERVER['SCRIPT_NAME']);
$enlaces = ['index.php' => 'Inicio', 'destinations.php' => 'Destinos', 'deals.php' => 'Ofertas', 'sucursales.php' => 'Sucursales'];
$logueado = clienteActual() !== null;
?>
<header class="site-header">
  <div class="wrap header-in">
    <a href="index.php" class="logo"><img src="assets/img/logo-1.png" alt="360 Travel" height="60"></a>
    <button class="menu-btn" aria-label="Abrir menú" aria-expanded="false"><i class="fa fa-bars"></i></button>
    <nav class="menu">
      <?php foreach ($enlaces as $url => $texto): ?>
        <a href="<?= $url ?>" <?= $actual === $url ? 'class="activo" aria-current="page"' : '' ?>><?= $texto ?></a>
      <?php endforeach; ?>
      <?php if ($logueado): ?>
        <a href="myReservation.php" <?= $actual === 'myReservation.php' ? 'class="activo" aria-current="page"' : '' ?>>Mis reservaciones</a>
        <form method="post" action="logout.php" class="form-salir">
          <input type="hidden" name="csrf" value="<?= e(csrf()) ?>">
          <button type="submit" class="btn-enlace">Cerrar sesión</button>
        </form>
      <?php else: ?>
        <a href="login.php" <?= $actual === 'login.php' ? 'class="activo" aria-current="page"' : '' ?>>Iniciar sesión</a>
      <?php endif; ?>
      <button type="button" class="tema-btn" aria-label="Cambiar a modo oscuro" aria-pressed="false" title="Cambiar tema">
        <svg class="i-luna" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>
        <svg class="i-sol" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>
      </button>
      <a href="reservation.php" class="btn btn-brasa">Reservar</a>
    </nav>
  </div>
</header>