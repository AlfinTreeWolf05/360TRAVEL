<?php
date_default_timezone_set('America/Mazatlan');
require_once __DIR__ . '/config/BD.php';

function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function pesos($n): string { return '$' . number_format((float)$n, 0, '.', ','); }

$fotos = ['country-01.jpg', 'country-02.jpg', 'country-03.jpg', 'banner-04.jpg'];
// Rangos sobre el precio YA con descuento: [etiqueta, mínimo, máximo (null = sin tope)]
$rangos = [
    '1' => ['Hasta $2,500', 0, 2500],
    '2' => ['$2,500 a $10,000', 2500, 10000],
    '3' => ['Más de $10,000', 10000, null],
];
$fDestino = (int)($_GET['destino'] ?? 0);
$fRango = (string)($_GET['precio'] ?? '');
if (!isset($rangos[$fRango])) { $fRango = ''; }

$base = "FROM ofertas o JOIN destino d ON d.ID_destino = o.ID_destino
          WHERE o.activo = 1 AND d.activo = 1 AND CURDATE() BETWEEN o.fecha_inicio AND o.fecha_fin";
$ofertas = $opciones = [];
$error = false;
try {
    $opciones = db()->query("SELECT DISTINCT d.ID_destino, d.nombre $base ORDER BY d.nombre")->fetchAll();

    $sql = "SELECT o.ID_oferta, o.ID_destino, o.titulo, o.descripcion, o.descuento, o.fecha_fin,
                   d.nombre, d.pais, d.imagen, d.duracion_dias, d.precio_desde $base";
    $params = [];
    if ($fDestino) { $sql .= ' AND o.ID_destino = ?'; $params[] = $fDestino; }
    if ($fRango !== '') {
        [, $min, $max] = $rangos[$fRango];
        $sql .= ' AND d.precio_desde * (1 - o.descuento / 100) >= ?'; $params[] = $min;
        if ($max !== null) { $sql .= ' AND d.precio_desde * (1 - o.descuento / 100) < ?'; $params[] = $max; }
    }
    $sql .= ' ORDER BY o.descuento DESC, d.nombre';
    $st = db()->prepare($sql);
    $st->execute($params);
    $ofertas = $st->fetchAll();
} catch (PDOException $ex) {
    error_log('deals.php: ' . $ex->getMessage());
    $error = true;
}

$titulo = 'Travel 360 - Ofertas';
$css_extra = 'assets/css/pages.css';
include 'parts/head.php';
include 'parts/header.php';
?>
<main>
  <section class="page-head">
    <div class="wrap">
      <p class="etiqueta">Ofertas</p>
      <h1>Ofertas de la temporada</h1>
      <p class="lead">Descuentos por tiempo limitado en destinos seleccionados.</p>
    </div>
  </section>

  <section class="wrap ofertas-seccion">
    <form class="buscador filtros" method="get" action="deals.php">
      <label>Destino
        <select name="destino">
          <option value="">Todos</option>
          <?php foreach ($opciones as $o): ?>
            <option value="<?= (int)$o['ID_destino'] ?>" <?= $fDestino === (int)$o['ID_destino'] ? 'selected' : '' ?>><?= e($o['nombre']) ?></option>
          <?php endforeach; ?>
        </select>
      </label>
      <label>Precio con descuento
        <select name="precio">
          <option value="">Cualquiera</option>
          <?php foreach ($rangos as $clave => $r): ?>
            <option value="<?= $clave ?>" <?= $fRango === (string)$clave ? 'selected' : '' ?>><?= e($r[0]) ?></option>
          <?php endforeach; ?>
        </select>
      </label>
      <button class="btn btn-teal" type="submit">Filtrar</button>
      <?php if ($fDestino || $fRango !== ''): ?><a class="limpiar" href="deals.php">Quitar filtros</a><?php endif; ?>
    </form>

    <?php if ($error): ?>
      <p class="vacio">No pudimos cargar las ofertas. Inténtalo de nuevo en unos minutos.</p>
    <?php elseif (!$ofertas): ?>
      <p class="vacio">No hay ofertas vigentes con esos filtros. <a href="deals.php">Ver todas</a></p>
    <?php else: ?>
      <div class="tarjetas">
        <?php foreach ($ofertas as $i => $o):
            $nuevo = round((float)$o['precio_desde'] * (1 - (int)$o['descuento'] / 100)); ?>
          <article class="tarjeta">
            <div class="tarjeta-img">
              <img src="assets/img/<?= e($o['imagen'] ?: $fotos[$i % count($fotos)]) ?>" alt="<?= e($o['nombre']) ?>" loading="lazy">
              <span class="chip"><?= e($o['pais']) ?></span>
              <span class="insignia">-<?= (int)$o['descuento'] ?>%</span>
            </div>
            <div class="tarjeta-cuerpo">
              <h3><?= e($o['titulo']) ?></h3>
              <?php if ($o['descripcion']): ?><p class="desc"><?= e($o['descripcion']) ?></p><?php endif; ?>
              <p class="meta"><i class="fa fa-clock"></i> <?= (int)$o['duracion_dias'] ?> días · <?= e($o['nombre']) ?></p>
              <p class="vigencia">Válida hasta el <?= (new DateTimeImmutable($o['fecha_fin']))->format('d/m/Y') ?></p>
              <div class="tarjeta-pie">
                <p class="precio"><small>Desde</small><span class="antes"><?= pesos($o['precio_desde']) ?></span><?= pesos($nuevo) ?></p>
                <a href="reservation.php?destino=<?= (int)$o['ID_destino'] ?>&amp;oferta=<?= (int)$o['ID_oferta'] ?>" class="btn btn-brasa btn-sm">Reservar</a>
              </div>
            </div>
          </article>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </section>
</main>
<?php include 'parts/pie.php'; ?>
