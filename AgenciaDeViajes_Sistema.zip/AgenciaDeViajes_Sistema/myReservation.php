<?php
require_once __DIR__ . '/config/BD.php';
require_once __DIR__ . '/config/Auth.php';
sesion();
$idCliente = requerirCliente();
$fecha = fn($f) => $f ? date('d/m/Y', strtotime($f)) : '—';

// ---- Cancelar una reservación pendiente (solo si es del cliente) ----
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $idR = (int)($_POST['cancelar'] ?? 0);
    if ($idR && csrfOk()) {
        try {
            $st = db()->prepare("UPDATE reservas SET estado = 'cancelada' WHERE ID_reserva = ? AND ID_cliente = ? AND estado = 'pendiente'");
            $st->execute([$idR, $idCliente]);
            $_SESSION['aviso'] = $st->rowCount() ? "La reservación #$idR fue cancelada." : 'Solo se pueden cancelar reservaciones pendientes.';
        } catch (PDOException $ex) {
            error_log('myReservation  cancelar: ' . $ex->getMessage());
            $_SESSION['aviso'] = 'No pudimos cancelar la reservación. Inténtalo más tarde.';
        }
    }
    irA('myReservation.php' . (!empty($_POST['volver_id']) ? '?id=' . (int)$_POST['volver_id'] : ''));
}
$aviso = $_SESSION['aviso'] ?? '';
unset($_SESSION['aviso']);

$id = (int)($_GET['id'] ?? 0);
$lista = []; $r = null; $detalle = $pagos = $facturas = []; $error = false;
try {
    if ($id) {
        $st = db()->prepare('SELECT ID_reserva, fecha_reserva, num_personas, estado, total_pagar FROM reservas WHERE ID_reserva = ? AND ID_cliente = ?');
        $st->execute([$id, $idCliente]);          
        $r = $st->fetch() ?: null;
        if ($r) {
            $st = db()->prepare('SELECT dr.fecha_inicio, dr.fecha_fin, dr.subtotal, s.nombre_servicio, s.tipo_servicio, d.nombre AS destino
                                   FROM detalle_reservas dr JOIN servicios s ON s.ID_servicio = dr.ID_servicio
                                   JOIN destino d ON d.ID_destino = dr.ID_destino WHERE dr.ID_reserva = ?');
            $st->execute([$id]); $detalle = $st->fetchAll();
            $st = db()->prepare('SELECT monto, metodo_pago, fecha_pago FROM pagos WHERE ID_reserva = ? ORDER BY fecha_pago');
            $st->execute([$id]); $pagos = $st->fetchAll();
            $st = db()->prepare('SELECT ID_facturas, cantidad_pagada, fecha FROM facturas WHERE ID_reserva = ? ORDER BY fecha');
            $st->execute([$id]); $facturas = $st->fetchAll();
        }
    } else {
        $st = db()->prepare("SELECT r.ID_reserva, r.fecha_reserva, r.estado, r.total_pagar,
                                    MIN(dr.fecha_inicio) AS inicio, MAX(dr.fecha_fin) AS fin,
                                    GROUP_CONCAT(DISTINCT d.nombre ORDER BY d.nombre SEPARATOR ', ') AS destinos
                               FROM reservas r
                               LEFT JOIN detalle_reservas dr ON dr.ID_reserva = r.ID_reserva
                               LEFT JOIN destino d ON d.ID_destino = dr.ID_destino
                              WHERE r.ID_cliente = ? GROUP BY r.ID_reserva ORDER BY r.ID_reserva DESC");
        $st->execute([$idCliente]);
        $lista = $st->fetchAll();
    }
} catch (PDOException $ex) {
    error_log('myReservation.php: ' . $ex->getMessage());
    $error = true;
}
if ($id && !$r && !$error) { http_response_code(404); }

$titulo = 'Travel 360 - Mis reservaciones';
$css_extra = 'assets/css/pages.css';
include 'parts/head.php';
include 'parts/header.php';
?>
<main>
  <section class="page-head">
    <div class="wrap">
      <p class="etiqueta">Mi cuenta</p>
      <h1>Hola, <?= e($_SESSION['cliente_nombre'] ?? '') ?></h1>
      <p class="lead"><?= $id ? '<a href="myReservation.php">← Todas mis reservaciones</a>' : 'Aquí puedes revisar tus reservaciones, pagos y facturas.' ?></p>
    </div>
  </section>
  <section class="wrap seccion-lista">
    <?php if ($aviso): ?><div class="aviso aviso-ok" role="status"><?= e($aviso) ?></div><?php endif; ?>
    <?php if ($error): ?>
      <p class="vacio">No pudimos cargar tus reservaciones. Inténtalo más tarde.</p>
    <?php elseif ($id && !$r): ?>
      <p class="vacio">No encontramos esa reservación. <a href="myReservation.php">Volver</a></p>
    <?php elseif ($id): ?>
      <div class="caja">
        <h2>Reservación #<?= (int)$r['ID_reserva'] ?> <span class="estado estado-<?= e($r['estado']) ?>"><?= e($r['estado']) ?></span></h2>
        <p class="suave">Registrada el <?= $fecha($r['fecha_reserva']) ?> · <?= (int)$r['num_personas'] ?> persona(s)</p>
        <div class="tabla-wrap"><table class="tabla">
          <thead><tr><th>Servicio</th><th>Destino</th><th>Salida</th><th>Regreso</th><th class="der">Subtotal</th></tr></thead>
          <tbody>
            <?php foreach ($detalle as $x): ?>
              <tr><td><?= e($x['nombre_servicio']) ?></td><td><?= e($x['destino']) ?></td><td><?= $fecha($x['fecha_inicio']) ?></td><td><?= $fecha($x['fecha_fin']) ?></td><td class="der"><?= pesos($x['subtotal']) ?></td></tr>
            <?php endforeach; ?>
          </tbody>
          <tfoot><tr><th colspan="4">Total</th><th class="der"><?= pesos($r['total_pagar']) ?></th></tr></tfoot>
        </table></div>
        <h3>Pagos</h3>
        <?php if (!$pagos): ?><p class="suave">Aún no hay pagos registrados.</p><?php else: ?>
          <ul class="mini-lista"><?php foreach ($pagos as $x): ?><li><?= $fecha($x['fecha_pago']) ?> · <?= e(ucfirst($x['metodo_pago'])) ?> · <strong><?= pesos($x['monto']) ?></strong></li><?php endforeach; ?></ul>
        <?php endif; ?>
        <h3>Facturas</h3>
        <?php if (!$facturas): ?><p class="suave">Aún no hay facturas.</p><?php else: ?>
          <ul class="mini-lista"><?php foreach ($facturas as $x): ?><li>Factura #<?= (int)$x['ID_facturas'] ?> · <?= $fecha($x['fecha']) ?> · <strong><?= pesos($x['cantidad_pagada']) ?></strong></li><?php endforeach; ?></ul>
        <?php endif; ?>
        <?php if ($r['estado'] === 'pendiente'): ?>
          <form method="post" action="myReservation.php" onsubmit="return confirm('¿Cancelar esta reservación?');">
            <input type="hidden" name="csrf" value="<?= e(csrf()) ?>">
            <input type="hidden" name="cancelar" value="<?= (int)$r['ID_reserva'] ?>">
            <input type="hidden" name="volver_id" value="<?= (int)$r['ID_reserva'] ?>">
            <button class="btn btn-linea" type="submit">Cancelar reservación</button>
          </form>
        <?php endif; ?>
      </div>
    <?php elseif (!$lista): ?>
      <div class="caja vacio"><p>Todavía no tienes reservaciones.</p><a href="reservation.php" class="btn btn-brasa">Hacer mi primera reservación</a></div>
    <?php else: ?>
      <div class="caja"><div class="tabla-wrap"><table class="tabla">
        <thead><tr><th>#</th><th>Destino</th><th>Fechas</th><th>Estado</th><th class="der">Total</th><th></th></tr></thead>
        <tbody>
          <?php foreach ($lista as $x): ?>
            <tr>
              <td><?= (int)$x['ID_reserva'] ?></td>
              <td><?= e($x['destinos'] ?: '—') ?></td>
              <td><?= $fecha($x['inicio']) ?> – <?= $fecha($x['fin']) ?></td>
              <td><span class="estado estado-<?= e($x['estado']) ?>"><?= e($x['estado']) ?></span></td>
              <td class="der"><?= pesos($x['total_pagar']) ?></td>
              <td><a href="myReservation.php?id=<?= (int)$x['ID_reserva'] ?>">Ver detalle</a></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table></div></div>
    <?php endif; ?>
  </section>
</main>
<?php include 'parts/pie.php'; ?>