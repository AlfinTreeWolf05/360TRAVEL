<?php
require_once __DIR__ . '/config/Auth.php';
sesion();
if ($_SERVER['REQUEST_METHOD'] === 'POST' && csrfOk()) {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
}
irA('index.php');
